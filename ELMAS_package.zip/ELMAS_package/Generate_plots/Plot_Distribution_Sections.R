###### INFORMATION ###### 
# File: Plot_Distribution_Sections.R
# Date: 2023-03-19
# Author: Kevin BELLINGUER
# Description: This script is used to generate the distributions of the averaged hourly standardised consumption of 
# three NACE sections according to the hour of the day, the day of the week, and the week of the year for the LV-a level (i.e. Figure 5 from the article
# "ELMAS: a one-year dataset of hourly electrical load profiles from 424 French industrial and tertiary sectors").

# WARNING: the script is provided but not the confidential data used to generate the plot (as a result, it is not possible to generate the graph)

#########################




source(fs::path("0_load_packages_functions.R") )

Section2plot = c("A" , "C" , "K")


# LOAD DATA ---------------------------------------------------------------

Correspondance_table = Load_correspondance_table() %>% 
  dplyr::select(Code.Section, NAF) %>% 
  dplyr::rename(Section = Code.Section , 
                Class = NAF )


PRO_ts = load_normalise_times_series_conso( path2load = fs::path("C:/Users/kevin.bellinguer/Documents/MOSAIC/Publication/Data/Confidential/" , 
                                                                 "PRO_Averaged_NACE_Time_series_2018.csv")  , 
                                            Power_level_name = "LV-a" ) 




# DATA PROCESSING ---------------------------------------------------------------

Sys.setlocale("LC_TIME","English")

All_data = dplyr::left_join( x = PRO_ts , 
                  y = Correspondance_table , 
                  by = c("Class")) %>% 
  dplyr::filter( Section %in% Section2plot ) %>% 
  dplyr::mutate(Day = as.Date(Time) , 
                week = lubridate::week(Time) ,
                day = lubridate::wday(Time , label = TRUE, abbr = FALSE) , 
                hour = lubridate::hour(Time))




to_plot_hourly = All_data %>% 
  
  dplyr::group_by( Class , hour ,Section ) %>% 
  dplyr::summarise( Mean_conso = mean(Conso , na.rm = T ) ) %>% 
  dplyr::ungroup() %>% 
  
  dplyr::group_by(Class) %>% 
  dplyr::mutate( Mean_conso = (Mean_conso - mean(Mean_conso , na.rm = T )) / sd(Mean_conso , na.rm = T )) %>% 
  dplyr::ungroup()  



to_plot_daily = All_data %>% 
  
  dplyr::group_by( Class , day , Section ) %>% 
  dplyr::summarise( Mean_conso = mean(Conso , na.rm = T ) ) %>% 
  dplyr::ungroup() %>% 
  
  dplyr::group_by(Class) %>% 
  dplyr::mutate( Mean_conso = (Mean_conso - mean(Mean_conso , na.rm = T )) / sd(Mean_conso , na.rm = T )) %>% 
  dplyr::ungroup()


to_plot_weekly = All_data %>% 
  
  dplyr::group_by( Class , week , Section ) %>% 
  dplyr::summarise( Mean_conso = mean(Conso , na.rm = T ) ) %>% 
  dplyr::ungroup() %>% 
  
  dplyr::group_by(Class) %>% 
  dplyr::mutate( Mean_conso = (Mean_conso - mean(Mean_conso , na.rm = T )) / sd(Mean_conso , na.rm = T )) %>% 
  dplyr::ungroup()  







# PLOT DATA ---------------------------------------------------------------


week_seq = c("Monday", "Tuesday", "Wednesday","Thursday", "Friday", "Saturday", "Sunday")
# week_seq = c("Mon.", "Tues.", "Wed.","Thur.", "Fri.", "Sat.", "Sun.")
table_week_conv = data.frame("time" = week_seq , 
                             'Week_num' = 1:7)


New_name = load_short_section_name()







png("Outputs/Figures/Section_NAF_Variability.png", 
    width = 700, 
    height = 600)


dplyr::bind_rows( to_plot_weekly %>% 
                    dplyr::filter(week %in% seq(1,53,1) ) %>% 
                    dplyr::rename(time = week) %>% 
                    dplyr::mutate(time_name = "Week"), 

                  to_plot_hourly %>% 
                    dplyr::rename(time = hour) %>% 
                    dplyr::mutate(time_name = "Hour") ,
                
                  to_plot_daily %>% 
                    dplyr::rename(time = day) %>% 
                    dplyr::mutate(time_name = "Day" ) %>% 
                    dplyr::left_join( x = . , 
                                      y = table_week_conv , 
                                      by = "time") %>% 
                    dplyr::select(-time) %>% 
                    dplyr::rename(time = Week_num) ,
) %>% 
  dplyr::mutate( time_name  = factor(x = time_name , 
                                     levels = c("Hour", 'Day' , "Week") ) ) %>% 
  
  dplyr::left_join( x = . , 
                    y = New_name %>% dplyr::select(-Section) %>% dplyr::rename( Section = Code.Section ) %>% dplyr::select( Section , Short_name ,Order_section ) ,
                    by = c("Section") ) %>% 
  
  
  ggplot(data = . , 
         mapping = aes(x = (time) , 
                       y = Mean_conso , 
                       colour =  Short_name ,  
                       group = interaction(time , Section) ) ) + 
  geom_boxplot( outlier.shape = NA , lwd=1 , width = 1 ) + 
  facet_wrap(  . ~ time_name  , scales = "free" , nrow = 3 , strip.position="right" ) + 
  basic_size_plot(22) + 
  scale_y_continuous(limits = c(-2.5 , 2.6) ) + 
  theme(legend.position = "top" , 
        axis.title.x=element_blank() ,
        legend.title = element_text(size = 20 , face = "bold" ) ,
        legend.text = element_text(size = 20) ) + 
  labs(x = "Week" ,
       y = "Standardised consumption" , 
       colour = "NACE section")

dev.off()

