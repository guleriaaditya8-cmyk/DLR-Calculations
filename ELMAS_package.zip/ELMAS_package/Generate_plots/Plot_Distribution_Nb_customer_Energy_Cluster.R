###### INFORMATION ###### 
# File: Plot_Distribution_Nb_customer_Energy_Cluster.R
# Date: 2023-03-19
# Author: Kevin BELLINGUER
# Description: This script is used to generate the distribution plot of the number of customer and the energy consumption according 
# to the clusters (i.e. Figure 9 from the article
# "ELMAS: a one-year dataset of hourly electrical load profiles from 424 French industrial and tertiary sectors").
#########################


source(fs::path("0_load_packages_functions.R") )



# DATA LOADING ------------------------------------------------------------

Clustered_data = 
  vroom::vroom(file = fs::path("Inputs/Clusters_after_manual_reclassification.csv") , 
               col_types = vroom::cols() ) %>% 
  dplyr::filter(Class != "0")


Yearly_Energy = vroom::vroom( file = fs::path( "Inputs/Annual_energy_weights.csv" ) ,
                              col_types = vroom::cols() , 
                              locale = vroom::locale(decimal_mark = ","))


all_data = dplyr::left_join( x = Clustered_data , 
                             y = Yearly_Energy , 
                             by = c("Power_level" , "Class") ) %>% 
  dplyr::filter(Section != "0")





# DATA PLOTTING ------------------------------------------------


data_2_plot = all_data %>% 
  
  dplyr::select(-Power_level ) %>% 
  dplyr::mutate( Energy = Energy / 10^9 ) %>% 
  
  dplyr::group_by(Cluster) %>% 
  dplyr::summarise(Nb_NACE = dplyr::n() , 
                Energy_cluster = sum(Energy) ) %>% 
  dplyr::ungroup() %>% 

  dplyr::mutate( Nb_NACE = as.numeric(Nb_NACE)) %>% 
  tidyfast::dt_pivot_longer(cols = -Cluster , names_to = "Type" , values_to = "Values") %>% 
  dplyr::as_tibble() %>% 
  
  dplyr::group_by(Type) %>% 
  dplyr::mutate( Pct = Values / sum(Values)) %>% 
  dplyr::ungroup() %>% 
  
  dplyr::mutate(Cluster = as.factor(Cluster) ,
                Type = ifelse(Type == "Nb_NACE" , "Nb. of NACE classes" , "Energy consumption (TWh)") , 
                Type = factor(Type , levels = c("Nb. of NACE classes" , "Energy consumption (TWh)") ))


data_2_plot %>% 
  dplyr::group_by(Type) %>% 
  dplyr::summarise( Pct = sum(Pct) )



dummy = data_2_plot %>% 
  dplyr::group_by(Type) %>% 
  dplyr::filter(Pct == max(Pct)) %>% 
  dplyr::ungroup() %>% 
  dplyr::mutate( Values = Values * 1.1 ) 



png("Outputs/Figures/Nb_Conso_Cluster.png", 
    width = 1100, 
    height = 600)

ggplot(data = data_2_plot ,
       mapping = aes( x = Cluster , 
                      y = Values , 
                      fill = Cluster ,
                      group = Type , 
                      label = scales::percent(Pct , accuracy = 0.01) ) ) + 
  geom_col( ) + 
  facet_wrap( Type ~ . , scales = "free" , ncol = 1 ) +
  basic_size_plot(size_text = 22) +
  
  theme(legend.position = "none" , 
        axis.title.y = element_blank()) + 
  geom_text(position = position_dodge(width = 0.9),    # move to center of bars
            vjust = -0.1,    # nudge above top of bar
            hjust = 0.5 ,
            angle = 0 , 
            fontface = "bold" ,
            size = 6) +
  geom_blank(data=dummy, aes(x = Cluster , y = Values ))


dev.off()