###### INFORMATION ###### 
# File: Plot_Distribution_Nace_Section_Before_After_Manual_Reclassification.R
# Date: 2023-03-19
# Author: Kevin BELLINGUER
# Description: This script is used to generate the distribution plot of the NACE sections before and after the manual reclassification process.
# This plot correspond to the Figure 8 from the article 
# "ELMAS: a one-year dataset of hourly electrical load profiles from 424 French industrial and tertiary sectors")
#########################


source(fs::path("0_load_packages_functions.R") )



Name_After = 'After manual reclassification'
Name_Before = 'Before manual reclassification'





# DATA LOADING ------------------------------------------------------------

Clustered_data_after = 
  vroom::vroom(file = fs::path("Inputs/Clusters_after_manual_reclassification.csv") , 
               col_types = vroom::cols() ) %>% 
  dplyr::filter(Class != "0") %>% 
  dplyr::mutate( Type = Name_After )



Clustered_data_before = 
  vroom::vroom( file = fs::path("Inputs/Clusters_before_manual_reclassification.csv") , 
                col_types = vroom::cols() ) %>%
  dplyr::filter(Class != "0") %>% 
  dplyr::mutate( Type = Name_Before)



Correspondance_table = Load_correspondance_table() %>% 
  dplyr::select(Code.Section , NAF) %>% 
  dplyr::rename(Section = Code.Section , 
                Class = NAF)


Yearly_Energy = vroom::vroom( file = fs::path( "Inputs/Annual_energy_weights.csv" ) ,
                              col_types = vroom::cols() , 
                              locale = vroom::locale(decimal_mark = ","))


New_Section_name = load_short_section_name() %>% dplyr::select( Code.Section , Short_name , Order_section ) %>% dplyr::rename(Section = Code.Section)



# DATA PREPROCESSING ------------------------------------------------------------


Clustered_data_after = dplyr::left_join( x = Clustered_data_after , 
                                         y = Correspondance_table , 
                                         by = "Class") %>% 
  dplyr::mutate( Section = ifelse(Class == "5/6/7/8" , "B" , Section ) , 
                 Section = ifelse(Class == "13.2/13.3" , "C" , Section ) ,  
                 Section = ifelse(Class == "23.4/23.3" , "C" , Section ) , 
                 Section = ifelse(Class == "33.17/33.16/33.15" , "C" , Section ) , 
                 Section = ifelse(Class == "30.2/30.1" , "C" , Section ) ) 



Clustered_data_before = dplyr::left_join( x = Clustered_data_before , 
                                          y = Correspondance_table , 
                                          by = "Class") %>% 
  dplyr::mutate( Section = ifelse(Class == "5/6/7/8" , "B" , Section ) , 
                 Section = ifelse(Class == "13.2/13.3" , "C" , Section ) ,  
                 Section = ifelse(Class == "23.4/23.3" , "C" , Section ) , 
                 Section = ifelse(Class == "33.17/33.16/33.15" , "C" , Section ) , 
                 Section = ifelse(Class == "30.2/30.1" , "C" , Section ) ) 



 





# DATA PLOTTING ------------------------------------------------------------


png("Outputs/Figures/reclassification.png", 
    width = 1100, 
    height = 600)



dplyr::bind_rows( Clustered_data_after , Clustered_data_before ) %>% 
  dplyr::left_join( x = . , 
                    y = Yearly_Energy , 
                    by = c("Power_level" , "Class" , "Section") ) %>% 
  
  dplyr::left_join( x = . , 
                    y = New_Section_name , 
                    by = "Section") %>% 
  
  # dplyr::filter( Section == "U")
  
  dplyr::group_by(Cluster , Type , Section , Short_name , Order_section ) %>% 
  dplyr::summarise( Conso = sum( Energy ) ) %>% 
  dplyr::ungroup() %>% 
  
  dplyr::group_by(Type , Cluster ) %>% 
  dplyr::mutate(Total_conso = sum(Conso)) %>% 
  dplyr::ungroup() %>% 
  
  dplyr::mutate( Pct_conso = Conso / Total_conso ) %>% 
  
  dplyr::mutate( Short_name = as.character(Short_name) , 
                 Short_name = factor(x = Short_name , 
                                     levels = New_Section_name$Short_name %>% unique() %>% as.character() %>% {.[-1]} %>% {.[21:1]} ) ) %>% 
  
  # dplyr::filter( Pct_conso > .5) %>% 
  
  dplyr::mutate( Type = factor( x = Type , levels = c( Name_Before , Name_After )) , 
                 Cluster = factor( x = as.character(Cluster) , levels = as.character(1:18) )  ) %>% 
  
  ggplot(data = . , 
         mapping = aes(x = Cluster , 
                       y = Short_name ,
                       fill = Pct_conso ) ) + 
  geom_tile() + 
  
  basic_size_plot(20) + 
  facet_wrap( . ~ Type , nrow = 1 ) + 
  scale_fill_gradientn( colours = colorRamps::matlab.like(10) , 
                        labels = scales::percent) + 
  theme( legend.position = "bottom" , 
         legend.title.align=0.5 ,
         legend.title = element_text( face = "bold" , size = 14) ,
         legend.key.width= unit(3, 'cm') ) +
  labs( y = "NACE sections" ,
        x = "Clusters" , 
        fill = "Annual energy consumption of the cluster") + 
  guides(fill = guide_colourbar(title.position = "top", title.hjust=0.5) )


dev.off()
