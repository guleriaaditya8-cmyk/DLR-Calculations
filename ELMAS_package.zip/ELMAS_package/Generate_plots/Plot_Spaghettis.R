###### INFORMATION ###### 
# File: Plot_Spaghettis.R
# Date: 2023-03-19
# Author: Kevin BELLINGUER
# Description: This script is used to generate the spaghetti plot (i.e. Figures 13, and 14 from the article
# "ELMAS: a one-year dataset of hourly electrical load profiles from 424 French industrial and tertiary sectors").

# WARNING: the script is provided but not the confidential data used to generate the plot (as a result, it is not possible to generate the graph). 

#########################




source(fs::path("0_load_packages_functions.R") )



Day_correspondance = data.frame(Dow = 1:7 , 
                                Dow_name = c("Mon." , "Tues." , "Wed." , "Thurs." , "Fri." , "Sat." , "Sun.")) %>% 
  dplyr::mutate(Dow_name = factor(x = Dow_name , 
                                  levels = c("Mon." , "Tues." , "Wed." , "Thurs." , "Fri." , "Sat." , "Sun.") ) )

Cluster_color = data.frame( "Cluster" = 1:18 , 
                            "fill_graph" =  gg_color_hue(n = 18) )

color_palette = data.frame( "Section" = as.character(1:18) ,
                            "Assigned_color" = gg_color_hue(n = 18))

manual_scale_colors <- setNames(color_palette$Assigned_color, color_palette$Section)




# LOAD DATA ---------------------------------------------------------------

Correspondance_table = Load_correspondance_table()
Cluster_ID_name = Load_correspondance_lcuster_ID_name()
Table_Fr_An = load_table_conv_Fr_An()




Clustered_data = 
  vroom::vroom( file = fs::path("Inputs/Clusters_after_manual_reclassification.csv") , 
                col_types = vroom::cols() ) %>%
  dplyr::filter(Class != "0") 



PRO_db = load_normalise_times_series_conso( path2load = fs::path("C:/Users/kevin.bellinguer/Documents/MOSAIC/Publication/Data/Confidential/" , 
                                                                 "PRO_Averaged_NACE_Time_series_2018.csv")  , 
                                            Power_level_name = "LV-a" )

MV_db = load_normalise_times_series_conso( path2load = fs::path("C:/Users/kevin.bellinguer/Documents/MOSAIC/Publication/Data/Confidential/" , 
                                                                "MV_Averaged_NACE_Time_series_2018.csv")  , 
                                           Power_level_name = "MV" )

LV_db = load_normalise_times_series_conso( path2load = fs::path("C:/Users/kevin.bellinguer/Documents/MOSAIC/Publication/Data/Confidential/" , 
                                                                "LV_Averaged_NACE_Time_series_2018.csv")  , 
                                           Power_level_name = "LV-b" )


All_data = dplyr::bind_rows( PRO_db , LV_db , MV_db)





All_weights = vroom::vroom( file = fs::path( "Inputs/Annual_energy_weights.csv" ) ,
                              col_types = vroom::cols() , 
                              locale = vroom::locale(decimal_mark = ","))






# DATA PREPROCESSING ---------------------------------------------------------------

All_data = All_data %>%
  dplyr::select(-Energy) %>% 
  
  dplyr::left_join( x = . , 
                    y = All_weights , 
                    by = c("Class" , "Power_level")) 



Data2gather = dplyr::left_join( y = Clustered_data , 
                                x = All_data , 
                                by = c("Class" , "Power_level") ) %>% 
  dplyr::mutate(Day = as.Date(Time) , 
                Week = lubridate::week(Time) ,
                Dow = lubridate::wday(Time , week_start = 1) , 
                Hod = lubridate::hour(Time)) %>% 
  dplyr::left_join(x = . , 
                   y = Day_correspondance , 
                   by = "Dow") %>% 
  dplyr::select(-Dow) 




Weekly_data_spaghetti = Data2gather %>% 
  dplyr::group_by(Cluster , Week , Class , Power_level , Energy) %>% 
  dplyr::summarise(Conso = mean(Conso , na.rm = T)) %>% 
  dplyr::ungroup() %>% 
  dplyr::mutate(Type_time = "Week of the year") %>% 
  dplyr::rename(Time = Week )

Daily_data_spaghetti = Data2gather %>% 
  dplyr::group_by(Cluster , Dow_name , Class , Power_level , Energy) %>% 
  dplyr::summarise(Conso = mean(Conso , na.rm = T)) %>% 
  dplyr::ungroup() %>% 
  dplyr::mutate(Type_time = "Day of the week") %>% 
  dplyr::rename(Time = Dow_name )

Hourly_data_spaghetti = Data2gather %>% 
  dplyr::group_by(Cluster , Hod , Class , Power_level , Energy) %>% 
  dplyr::summarise(Conso = mean(Conso , na.rm = T)) %>% 
  dplyr::ungroup() %>% 
  dplyr::mutate(Type_time = "Hour of the day") %>% 
  dplyr::rename(Time = Hod )









Weekly_data_mean = Data2gather %>% 
  dplyr::group_by(Cluster, Week) %>% 
  dplyr::summarise( Mean = sum( Conso * Energy , na.rm = T ) / sum( Energy , na.rm = T ) ) %>%
  dplyr::ungroup() %>% 
  dplyr::mutate(Type_time = "Week of the year") %>% 
  dplyr::rename(Time = Week )

Daily_data_mean = Data2gather %>% 
  dplyr::group_by(Cluster, Dow_name) %>% 
  dplyr::summarise( Mean = sum( Conso * Energy , na.rm = T )/sum( Energy , na.rm = T ) ) %>%
  dplyr::ungroup() %>% 
  dplyr::mutate(Type_time = "Day of the week") %>% 
  dplyr::rename(Time = Dow_name )


Hourly_data_mean = Data2gather %>% 
  dplyr::group_by(Cluster, Hod) %>% 
  dplyr::summarise( Mean = sum( Conso * Energy , na.rm = T )/sum( Energy , na.rm = T ) ) %>%
  dplyr::ungroup() %>% 
  dplyr::mutate(Type_time = "Hour of the day") %>% 
  dplyr::rename(Time = Hod )








data_spaghetti =  dplyr::bind_rows( Weekly_data_spaghetti %>% dplyr::mutate( Time = paste0("w" , Time) , 
                                                                             Time = factor(x = Time , 
                                                                                           levels = paste0("w" , 1:53))) , 
                                    Daily_data_spaghetti ,
                                    Hourly_data_spaghetti %>% dplyr::mutate( Time = paste0("d" , Time) , 
                                                                             Time = factor(x = Time , 
                                                                                           levels = paste0("d" , 0:23)) )  ) %>% 
  dplyr::mutate( Type_time = factor(x = Type_time  , 
                                    levels = c( "Hour of the day" , "Day of the week" , "Week of the year" ) ) )


data_mean = dplyr::bind_rows( Weekly_data_mean %>% dplyr::mutate( Time = paste0("w" , Time) , 
                                                                  Time = factor(x = Time , 
                                                                                levels = paste0("w" , 1:53))) , 
                              Daily_data_mean ,
                              Hourly_data_mean %>% dplyr::mutate( Time = paste0("d" , Time) , 
                                                                  Time = factor(x = Time , 
                                                                                levels = paste0("d" , 0:23))   ) )  %>% 
  dplyr::mutate( Type_time = factor(x = Type_time  , 
                                    levels = c( "Hour of the day" , "Day of the week" , "Week of the year" ) ) )





nb_word_new_line = 2


all_data = dplyr::left_join( x = data_spaghetti  ,
                             y = data_mean , 
                             by = c("Cluster" , "Time" , "Type_time")) %>% 
  dplyr::left_join( x = . , 
                    y = Cluster_ID_name %>% 
                      dplyr::select(ID , Name_id) %>% dplyr::rename(Cluster = ID) %>%   
                      dplyr::rowwise() %>% 
                      dplyr::mutate( Name_id = fun_sparse_sentence(str = Name_id , n = nb_word_new_line ) ) %>% 
                      dplyr::ungroup() %>% 
                      dplyr::mutate(Cluster = as.numeric(Cluster)) , 
                    by = c("Cluster") ) 



# PLOT DATA ---------------------------------------------------------------


cluster2plot = 1:9



png("Outputs/Figures/Generated_profiles_1.png", 
    width = 1700, 
    height = 1400)


ggplot(data = all_data  %>% 
         dplyr::filter(Cluster %in% cluster2plot)  ) + 
  geom_line( mapping = aes(x = Time ,
                           y = Conso ,
                           color = as.factor(Cluster) ,
                           group = interaction(Class,Power_level) ,
                           alpha = interaction(Cluster ,  Energy)) ,
             # colour = "grey" 
  ) + 
  geom_line( mapping = aes(x = Time , 
                           y = Mean , 
                           group = interaction(Class,Power_level) ) ,
             # colour = "black" ,
             linewidth = 1) +
  basic_size_plot(24) + 
  scale_color_manual(values = manual_scale_colors) +
  
  labs(y = "Standardised consumption") +
  theme(legend.position = "none") +
  facet_grid( Name_id ~ Type_time , 
              scales = "free" ) + 
  
  theme( axis.title.x = element_blank() , 
         strip.text.y.right = element_text(angle = 0) ) +
  scale_x_discrete(labels=c("Tues." = "" , 
                            "Thurs." = "" , 
                            "Sat." = "" , 
                            "d0" = "0" , "d2" = "" , "d4" = "4" , "d6" = "" , "d8" = "8" , "d10" = "" , "d12" = "12" , "d14" = "" , "d16" = "16" , "d18" = "" , "d20" = "20" , "d22" = "" , 
                            "d1" = "" , "d3" = "" , "d5" = "" , "d7" = "" , "d9" = "" , "d11" = "" , "d13" = "" , "d15" = "" , "d17" = "" , "d19" = "" , "d21" = "" , "d23" = "" , 
                            "w1" = "1" , "w2" = "" , "w3" = "" , "w4" = "" , "w5" = "" , "w6" = "" , "w7" = "" , "w8" = "" , "w9" = "" ,
                            "w10" = "10" , "w11" = "" , "w12" = "" , "w13" = "" , "w14" = "" , "w15" = "" , "w16" = "" , "w17" = "" , "w18" = "" , "w19" = "" , 
                            "w20" = "20" , "w21" = "" , "w22" = "" , "w23" = "" , "w24" = "" , "w25" = "" , "w26" = "" , "w27" = "" , "w28" = "" , "w29" = "" , 
                            "w30" = "30" , "w31" = "" , "w32" = "" , "w33" = "" , "w34" = "" , "w35" = "" , "w36" = "" , "w37" = "" , "w38" = "" , "w39" = "" , 
                            "w40" = "40" , "w41" = "" , "w42" = "" , "w43" = "" , "w44" = "" , "w45" = "" , "w46" = "" , "w47" = "" , "w48" = "" , "w49" = "" , 
                            "w50" = "50" , "w51" = "" , "w52" = "" , "w53" = "" , "w54" = "" , "w55" = "" , "w56" = "" , "w57" = "" , "w58" = "" , "w59" = "" )) +
  ylim(-2, 2)  


dev.off()











cluster2plot = 10:18



png("Outputs/Figures/Generated_profiles_2.png", 
    width = 1700, 
    height = 1400)


ggplot(data = all_data  %>% 
         dplyr::filter(Cluster %in% cluster2plot)  ) + 
  geom_line( mapping = aes(x = Time ,
                           y = Conso ,
                           color = as.factor(Cluster) ,
                           group = interaction(Class,Power_level) ,
                           alpha = interaction(Cluster ,  Energy)) ,
             # colour = "grey" 
  ) + 
  geom_line( mapping = aes(x = Time , 
                           y = Mean , 
                           group = interaction(Class,Power_level) ) ,
             # colour = "black" ,
             linewidth = 1) +
  basic_size_plot(24) + 
  scale_color_manual(values = manual_scale_colors) +
  
  labs(y = "Standardised consumption") +
  theme(legend.position = "none") +
  facet_grid( Name_id ~ Type_time , 
              scales = "free" ) + 
  
  theme( axis.title.x = element_blank() , 
         strip.text.y.right = element_text(angle = 0) ) +
  scale_x_discrete(labels=c("Tues." = "" , 
                            "Thurs." = "" , 
                            "Sat." = "" , 
                            "d0" = "0" , "d2" = "" , "d4" = "4" , "d6" = "" , "d8" = "8" , "d10" = "" , "d12" = "12" , "d14" = "" , "d16" = "16" , "d18" = "" , "d20" = "20" , "d22" = "" , 
                            "d1" = "" , "d3" = "" , "d5" = "" , "d7" = "" , "d9" = "" , "d11" = "" , "d13" = "" , "d15" = "" , "d17" = "" , "d19" = "" , "d21" = "" , "d23" = "" , 
                            "w1" = "1" , "w2" = "" , "w3" = "" , "w4" = "" , "w5" = "" , "w6" = "" , "w7" = "" , "w8" = "" , "w9" = "" ,
                            "w10" = "10" , "w11" = "" , "w12" = "" , "w13" = "" , "w14" = "" , "w15" = "" , "w16" = "" , "w17" = "" , "w18" = "" , "w19" = "" , 
                            "w20" = "20" , "w21" = "" , "w22" = "" , "w23" = "" , "w24" = "" , "w25" = "" , "w26" = "" , "w27" = "" , "w28" = "" , "w29" = "" , 
                            "w30" = "30" , "w31" = "" , "w32" = "" , "w33" = "" , "w34" = "" , "w35" = "" , "w36" = "" , "w37" = "" , "w38" = "" , "w39" = "" , 
                            "w40" = "40" , "w41" = "" , "w42" = "" , "w43" = "" , "w44" = "" , "w45" = "" , "w46" = "" , "w47" = "" , "w48" = "" , "w49" = "" , 
                            "w50" = "50" , "w51" = "" , "w52" = "" , "w53" = "" , "w54" = "" , "w55" = "" , "w56" = "" , "w57" = "" , "w58" = "" , "w59" = "" )) +
  ylim(-2, 2)  


dev.off()

