###### INFORMATION ###### 
# File: Plot_Score_Kmeans.R
# Date: 2023-03-19
# Author: Kevin BELLINGUER
# Description: This script is used to generate the Distortion, inertia, and silhouette curves (i.e. Figure 7 from the article
# "ELMAS: a one-year dataset of hourly electrical load profiles from 424 French industrial and tertiary sectors").

#########################



source(fs::path("0_load_packages_functions.R") )



# LOAD DATA ---------------------------------------------------------------


All_Score = vroom::vroom(file = fs::path( "Inputs" , "Kmeans_scores.csv" ) , 
             col_types = vroom::cols() ) %>% 
  dplyr::select(-Iteration) %>% 
  dplyr::rename(Distortion = DistortionScore , 
                Inertia = InertiaScore , 
                Silhouette = SilhouetteScore) %>% 
  tidyfast::dt_pivot_longer(cols = c(-NbClusters ) , names_to = "Score" , values_to = "Value") %>% 
  dplyr::as_tibble()





# PLOT DATA ---------------------------------------------------------------


Nb_cluster_keep = 16



png("Outputs/Figures/Score_curves.png", 
    width = 1200, 
    height = 600)


All_Score %>% 
  dplyr::group_by( NbClusters , Score ) %>% 
  dplyr::summarise(Value = mean(Value , na.rm = T)) %>% 
  dplyr::ungroup() %>% 
  
  ggplot(data = . , 
         mapping = aes(x = NbClusters  , 
                       y = Value ) ) +
  geom_point() +
  geom_line() + 
  facet_wrap( Score ~ . , scales = "free") +
  basic_size_plot(size_text = 24) + 
  labs(x = "Nb. of clusters" , y = "Scores") + 
  geom_vline(xintercept=Nb_cluster_keep , linetype = "dashed" , color = "red" , size = 1 )



dev.off()