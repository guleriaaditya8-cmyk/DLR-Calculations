###### INFORMATION ###### 
# File: Plot_Distribution_Indicators.R
# Date: 2023-03-19
# Author: Kevin BELLINGUER
# Description: This script is used to generate the distribution plot of indicators (i.e. Figures 15 from the article
# "ELMAS: a one-year dataset of hourly electrical load profiles from 424 French industrial and tertiary sectors").

# WARNING: the script is provided but not the confidential data used to generate the plot (as a result, it is not possible to generate the graph)

#########################




source(fs::path("0_load_packages_functions.R") )






# LOAD DATA ---------------------------------------------------------------


Clusters_association = 
  vroom::vroom( file = fs::path("Inputs/Clusters_after_manual_reclassification.csv") , 
                col_types = vroom::cols() ) %>%
  dplyr::filter(Class != "0") 



Temperature_TS = vroom::vroom(file = fs::path("Inputs/Temperature.csv") ,
                              col_types = vroom::cols() ,
                              locale = vroom::locale(decimal_mark = ","))


PRO_ts = load_normalise_times_series_conso( path2load = fs::path("C:/Users/kevin.bellinguer/Documents/MOSAIC/Publication/Data/Confidential/" , 
                                                                 "PRO_Averaged_NACE_Time_series_2018.csv")  , 
                                            Power_level_name = "LV-a" ) 

MV_ts = load_normalise_times_series_conso( path2load = fs::path("C:/Users/kevin.bellinguer/Documents/MOSAIC/Publication/Data/Confidential/" , 
                                                                "MV_Averaged_NACE_Time_series_2018.csv")  , 
                                           Power_level_name = "MV" ) 


LV_ts = load_normalise_times_series_conso( path2load = fs::path("C:/Users/kevin.bellinguer/Documents/MOSAIC/Publication/Data/Confidential/" , 
                                                                "LV_Averaged_NACE_Time_series_2018.csv")  , 
                                           Power_level_name = "LV-b" ) 




All_data_NACE = dplyr::bind_rows( PRO_ts , LV_ts , MV_ts )  %>% 
  dplyr::left_join( x = . , 
                    y = Clusters_association  , 
                    by = c("Class" , "Power_level"))  %>% 
  dplyr::select(-Energy)  %>% 
  dplyr::left_join( x = . , 
                    y = Temperature_TS , 
                    by = c("Time"))










All_TS_indicator = Compute_TS_per_Class( db = All_data_NACE  )


# All_TS_indicator %>% 
#   dplyr::filter(Cluster == 18 ) %>% 
#   dplyr::filter(Alpha < -0.1)



# All_TS_indicator %>% 
#   dplyr::as_tibble() %>% 
#   
#   dplyr::mutate(Cluster = as.factor(Cluster)) %>% 
#   
#   ggplot(data = . , mapping = aes(x = Cluster , y  = Alpha , group = Cluster , fill = Cluster ) ) + 
#   geom_boxplot() +
#   basic_size_plot(20) +
#   theme(legend.position = "none") +
#   labs(y = "Thermosensitivity (/°C)")



All_season = Compute_diff_season( db = All_data_NACE )




# All_season %>% 
#   dplyr::mutate(Cluster = as.factor(Cluster)) %>% 
#   
#   ggplot(data = . , mapping = aes(x = Cluster , y  = Diff , group = Cluster , fill = Cluster ) ) + 
#   geom_boxplot() +
#   basic_size_plot(20) +
#   theme(legend.position = "none") 






All_week_end = Compute_diff_week_day_end(db = All_data_NACE)


# All_week_end %>% 
#   dplyr::mutate(Cluster = as.factor(Cluster)) %>% 
#   
#   ggplot(data = . , mapping = aes(x = Cluster , y  = Diff , group = Cluster , fill = Cluster ) ) + 
#   geom_boxplot() +
#   basic_size_plot(20) +
#   theme(legend.position = "none") 



All_hour = Compute_diff_hour(db = All_data_NACE )




# All_hour %>% 
#   dplyr::mutate(Cluster = as.factor(Cluster)) %>% 
#   
#   ggplot(data = . , mapping = aes(x = Cluster , y  = Diff , group = Cluster , fill = Cluster ) ) + 
#   geom_boxplot() +
#   basic_size_plot(20) +
#   theme(legend.position = "none") 






png("Outputs/Figures/Indicator.png", 
    width = 1700, 
    height = 1200)


dplyr::bind_rows( 
  All_TS_indicator %>% 
    dplyr::select(-Cor) %>% 
    dplyr::rename(Value = Alpha) %>% 
    dplyr::mutate(Type = "Thermosensivity (/°C)") , 
  
  All_season %>% 
    dplyr::select(-Summer, -Winter , - Ratio) %>% 
    dplyr::rename(Value = Diff ) %>% 
    dplyr::mutate(Type = "Seasonal variation") , 
  
  All_week_end %>% 
    dplyr::select(-Week_end, -Working_day , - Ratio) %>% 
    dplyr::rename(Value = Diff ) %>% 
    dplyr::mutate(Type = "Daily variation") ,
  
  All_hour %>% 
    dplyr::select(-Day, -Night , - Ratio) %>% 
    dplyr::rename(Value = Diff ) %>% 
    dplyr::mutate(Type = "Hourly variation") ,
  
) %>% 
  dplyr::mutate(Cluster = as.factor(Cluster) , 
                Type = factor(x = Type , levels = c("Thermosensivity (/°C)" , "Seasonal variation" , "Daily variation" , "Hourly variation" ))) %>% 
  
  
  ggplot(data = . , mapping = aes(x = Cluster , y  = Value , group = Cluster , fill = Cluster ) ) + 
  geom_boxplot() +
  basic_size_plot(20) +
  theme(legend.position = "none") +
  
  facet_grid( Type ~ . , scales = "free") + 
  theme(axis.title.y = element_blank()) + 
  stat_summary(fun = mean, geom="point", shape=18, size=4, color="black", fill="black")


dev.off()

