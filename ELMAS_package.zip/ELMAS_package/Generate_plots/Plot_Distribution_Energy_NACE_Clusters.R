###### INFORMATION ###### 
# File: Plot_Distribution_Energy_NACE_Clusters.R
# Date: 2023-03-19
# Author: Kevin BELLINGUER
# Description: This script is used to generate the distribution plot of the NACE section within each cluster and the corresponding annual energy consumption 
# (i.e. Figures 10, 11, 12 from the article "ELMAS: a one-year dataset of hourly electrical load profiles from 424 French industrial and tertiary sectors").
#########################

source(fs::path("C:/Users/kevin.bellinguer/Documents/MOSAIC/Publication/Data/Code/0_load.R") )




# DATA LOADING ------------------------------------------------------------

Clustered_data = 
  vroom::vroom(file = fs::path("Inputs/Clusters_after_manual_reclassification.csv") , 
               col_types = vroom::cols() ) %>% 
  dplyr::filter(Class != "0") 


Yearly_Energy = vroom::vroom( file = fs::path( "Inputs/Annual_energy_weights.csv" ) ,
                              col_types = vroom::cols() , 
                              locale = vroom::locale(decimal_mark = ","))


all_data = dplyr::left_join( x = Clustered_data , 
                             y = Yearly_Energy , 
                             by = c("Power_level" , "Class") ) %>% 
  dplyr::filter(Section != "0")




New_Section_name = load_short_section_name()
New_classe_name = load_short_classe_name( Max_char = 30 )





# DATA PLOTTING  ----------------------------------------------------------------

Cluster2plot = 1:18

Conso_tot = all_data$Energy %>% sum() %>% {./ 10^9}


data_big_plot = all_data %>% 
  
  dplyr::filter(Cluster %in% Cluster2plot) %>% 
  dplyr::mutate( Energy = Energy / 10^9) %>% 
  
  dplyr::group_by(Class , Section , Cluster) %>% 
  dplyr::summarise( Energy = sum(Energy)) %>% 
  dplyr::ungroup() %>% 
  
  dplyr::mutate(Conso_total = Conso_tot ) %>% 
  
  dplyr::group_by(Cluster) %>% 
  dplyr::mutate(Conso_cluster = sum(Energy)) %>% 
  dplyr::ungroup() %>% 
  
  dplyr::group_by(Cluster , Section) %>% 
  dplyr::mutate(Conso_section = sum(Energy)) %>% 
  dplyr::ungroup() %>% 
  
  dplyr::group_by(Cluster , Class ) %>% 
  dplyr::mutate(Conso_classe = sum(Energy)) %>% 
  dplyr::ungroup() %>% 
  
  dplyr::mutate(Section_fill = Section) %>% 
  
  dplyr::mutate( Pct_cluster =  round( 100 * Conso_cluster / Conso_total , 2 ) , 
                 Pct_Section = Conso_section / Conso_cluster ,
                 Pct_Classe = Conso_classe / Conso_cluster ) %>% 
  dplyr::select(-Conso_cluster , - Conso_total ) %>% 
  
  dplyr::left_join( x = . , 
                    y = New_Section_name %>% 
                      dplyr::select(Code.Section , Short_name , Order_section) %>% 
                      dplyr::rename( Section = Code.Section  ,
                                     Short_name_section = Short_name) , 
                    by = c("Section") ) %>% 
  dplyr::left_join( x = . , 
                    y = New_classe_name %>% 
                      dplyr::rename(Class = Classe) %>% 
                      dplyr::select( Class , Short_name , Order_classe ) %>% 
                      dplyr::rename( Short_name_classe = Short_name ) , 
                    by = c("Class") ) 






png("Outputs/Figures/New_Energy_distribution_cluster_per_section_classe_1.png", 
    width = 1700, 
    height = 1400)

ggarrange( Get_plot_Section_clusters( data4ploting = data_big_plot %>% dplyr::filter(Cluster %in% 1:6) ) , 
           Get_plot_Classe_clusters( data4ploting = data_big_plot %>% dplyr::filter(Cluster %in% 1:6) ),
           widths = c(1,2.5 ),
           ncol = 2, nrow = 1 ,
           common.legend = TRUE, 
           legend="bottom")


dev.off()




png("Outputs/Figures/New_Energy_distribution_cluster_per_section_classe_2.png", 
    width = 1700, 
    height = 1400)

ggarrange( Get_plot_Section_clusters( data4ploting = data_big_plot %>% dplyr::filter(Cluster %in% 7:12) ) , 
           Get_plot_Classe_clusters( data4ploting = data_big_plot %>% dplyr::filter(Cluster %in% 7:12) ),
           widths = c(1,2.5 ),
           ncol = 2, nrow = 1 ,
           common.legend = TRUE, 
           legend="bottom")

dev.off()



png("Outputs/Figures/New_Energy_distribution_cluster_per_section_classe_3.png", 
    width = 1700, 
    height = 1400)

ggarrange( Get_plot_Section_clusters( data4ploting = data_big_plot %>% dplyr::filter(Cluster %in% 13:18) ) , 
           Get_plot_Classe_clusters( data4ploting = data_big_plot %>% dplyr::filter(Cluster %in% 13:18) ),
           widths = c(1,2.5 ),
           ncol = 2, nrow = 1 ,
           common.legend = TRUE, 
           legend="bottom")

dev.off()


