###### INFORMATION ###### 
# File: Plot_Extra_Intra_cluster_Error.R
# Date: 2023-03-19
# Author: Kevin BELLINGUER
# Description: This script is used to generate the error plot between the different clusters (i.e. Figure 16 from the article
# "ELMAS: a one-year dataset of hourly electrical load profiles from 424 French industrial and tertiary sectors").
#########################

source(fs::path("0_load_packages_functions.R") )








# DATA LOADING ------------------------------------------------------------


Table_Fr_An = load_table_conv_Fr_An()
Table_section_class = Load_correspondance_table()



Mean_Profil_cluster = 
  fs::path( "Outputs" , "Time_series_averaged_18_clusters.csv") %>% 
  vroom::vroom(file = . , 
               col_types = vroom::cols() ,
               locale = vroom::locale(decimal_mark = ",") ) %>% 
  tidyr::pivot_longer(cols = -Time , names_to = "Cluster" , values_to = "Conso_mean") %>% 
  dplyr::mutate( Cluster = as.numeric(Cluster))



Clusters_association = 
  vroom::vroom( file = fs::path("Inputs/Clusters_after_manual_reclassification.csv") , 
                col_types = vroom::cols() ) %>%
  dplyr::filter(Class != "0") 




PRO_ts = load_normalise_times_series_conso( path2load = fs::path("C:/Users/kevin.bellinguer/Documents/MOSAIC/Publication/Data/Confidential/" , 
                                                                 "PRO_Averaged_NACE_Time_series_2018.csv")  , 
                                            Power_level_name = "LV-a" ) 

MV_ts = load_normalise_times_series_conso( path2load = fs::path("C:/Users/kevin.bellinguer/Documents/MOSAIC/Publication/Data/Confidential/" , 
                                                                "MV_Averaged_NACE_Time_series_2018.csv")  , 
                                           Power_level_name = "MV" ) 


LV_ts = load_normalise_times_series_conso( path2load = fs::path("C:/Users/kevin.bellinguer/Documents/MOSAIC/Publication/Data/Confidential/" , 
                                                                "LV_Averaged_NACE_Time_series_2018.csv")  , 
                                           Power_level_name = "LV-b" ) 




All_data_NACE = dplyr::bind_rows( PRO_ts , LV_ts , MV_ts )  %>% 
  dplyr::left_join( x = . , 
                    y = Clusters_association , 
                    by = c("Class" , "Power_level"))  %>% 
  dplyr::select(-Energy)  
# dplyr::left_join( x = . ,
#                   y = Mean_Profil_cluster , 
#                   by = c("Time" , "Cluster"))




# DATA PROCESSING ------------------------------------------------------------

NACE_per_cluster_split = All_data_NACE %>% 
  dplyr::group_split(Cluster)




All_score = foreach::foreach( index_cluster = 1 : length(NACE_per_cluster_split) ) %do% {
  
  Current_split = index_cluster %>% NACE_per_cluster_split[[.]]
  Current_cluster = Current_split$Cluster %>% unique()
  
  
  temp = dplyr::full_join( y = Current_split , 
                           x = Mean_Profil_cluster %>% dplyr::rename(Extra_cluster = Cluster ) , 
                           by = c("Time") )  
  
  
  temp %>% 

    dplyr::group_by( Extra_cluster , Class , Power_level ) %>% 
    dplyr::summarise( RMSE = sqrt(mean( (Conso_mean - Conso)^2 ,  na.rm = F )) , 
                      MAE = mean( abs(Conso_mean - Conso) ,  na.rm = F ) ) %>% 
    dplyr::ungroup() %>% 
    dplyr::mutate(Intra_cluster  = Current_cluster )
  
} %>% 
  dplyr::bind_rows()







# DATA PLOTTING ------------------------------------------------------------


png("Outputs/Figures/Score_MAE_RMSE.png", 
    width = 1500, 
    height = 1000)


All_score %>% 
  
  dplyr::group_by( Extra_cluster , Intra_cluster ) %>%
  dplyr::summarise( RMSE = mean(RMSE) ,
                    MAE = mean(MAE)) %>%
  dplyr::ungroup() %>%
  
  tidyr::pivot_longer( cols = c(-Extra_cluster , -Intra_cluster  ) , 
                       names_to = "Score" , 
                       values_to = "Value") %>% 

  dplyr::group_by(Intra_cluster , Score) %>% 
  dplyr::arrange(Value) %>% 
  dplyr::mutate( Order = 1:dplyr::n() ) %>% 
  
  dplyr::ungroup() %>% 
  
  dplyr::rename(Rank = Order) %>% 

  ggplot(data = . , 
         mapping = aes( y = Extra_cluster , x = Intra_cluster , fill = Rank , group = Extra_cluster  ) ) + 
  geom_tile(color = "white" , alpha = 0.9) +

  facet_grid( . ~ Score , scales = "free" , space = "free") +
  scale_fill_gradientn( colours = colorRamps::matlab.like(10) ) + 
  basic_size_plot(20) + 
  labs(x = "Intra-cluster" , y = "Extra-cluster") +
  theme(legend.title = element_text(face = "bold" , size = 18) , 
        legend.text = element_text(size = 16) , 
        legend.key.size = unit(1, 'cm') )



dev.off()