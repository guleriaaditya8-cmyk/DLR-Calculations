###### INFORMATION ###### 
# File: Plot_Distribution_Nb_customer_Energy_large_panel.R
# Date: 2023-03-19
# Author: Kevin BELLINGUER
# Description: This script is used to generate the distribution plot of the energy consumption according 
# to the NACE section and the level of subscribed power (i.e. Figure 4 from the article
# "ELMAS: a one-year dataset of hourly electrical load profiles from 424 French industrial and tertiary sectors").
# The data considered corresponds to the annual energy consumption of the large panel used for the weighting strategy.
#########################




source(fs::path("0_load_packages_functions.R") )



# DATA LOADING ------------------------------------------------------------


Nb_customer.df = vroom::vroom( file = fs::path( "Inputs/Nb_customers_time_series.csv" ) , 
                               col_types = vroom::cols() ) %>% 
  dplyr::filter(Nb_customer != 0)


Energy.df = vroom::vroom( file = fs::path( "Inputs/Annual_energy_weights.csv" ) , 
                          col_types = vroom::cols() ,
                          locale = vroom::locale(decimal_mark = ",") ) %>% 
  dplyr::left_join( x = Nb_customer.df %>% dplyr::select(-Nb_customer) , 
                    y = . , 
                    by = c("Section" , "Class" , "Power_level")) %>% 
  
  tidyr::pivot_wider( id_cols = c(Section , Class) , 
                      names_from = Power_level , 
                      values_from = Energy) %>% 
  tidyr::replace_na(replace = list( `LV-a` = 0, 
                                    `LV-b` = 0 , 
                                    `MV` = 0) ) %>% 
  dplyr::mutate(Total = `LV-a` + `LV-b` + `MV`) 




all_data = Energy.df %>% 
  tidyr::pivot_longer( cols =c(-Section , -Class) , 
                       names_to = "Power_level" ,
                       values_to = "Energy" ) %>% 
  dplyr::mutate( Energy = Energy / (10^9)) 
# dplyr::filter(is.na(Energy))




# PLOT ENERGY DISTRIBUTION -------------------------------------------------------------



all_data_new = all_data  %>%
  
  dplyr::mutate( Power_level = ifelse( Power_level == "Total" , "LV-MV" , Power_level ) , 
                 Power_level = factor(x = Power_level , levels = c("LV-a" , "LV-b" , "MV" , "LV-MV"))) %>% 
  
  dplyr::filter( Section != "0" ) %>%
  
  dplyr::group_by(Power_level , Section) %>% 
  dplyr::summarise(Energy =  sum(Energy) ) %>% 
  dplyr::ungroup() %>% 
  
  dplyr::group_by(Power_level) %>% 
  dplyr::mutate(Pct =  Energy / sum(Energy) ) %>% 
  dplyr::ungroup() %>% 
  
  dplyr::left_join(x = . , 
                   y = Section_name %>% 
                     dplyr::select(Code.Section , Short_name , Order_section)  %>% dplyr::rename(Section = Code.Section) , 
                   by = c("Section"))


dummy = all_data_new %>% 
  dplyr::group_by(Power_level) %>% 
  dplyr::filter(Energy == max(Energy)) %>% 
  dplyr::ungroup() %>% 
  dplyr::mutate( Energy = Energy * 1.2 )




png("Outputs/Figures/Distribution_Energy_large_panel.png", 
    width = 1200, 
    height = 600)

all_data_new  %>% 
  
  ggplot(data = . , 
         aes(y = Energy   ,
             fill = Section , 
             x = forcats::fct_rev(Short_name) , 
             label = scales::percent(Pct , accuracy = 0.01) )) + 
  geom_col(position = 'dodge') +
  
  facet_grid( . ~ Power_level ,scales =  "free") +
  
  coord_flip() +
  
  geom_text(position = position_dodge(width = 0.9),    # move to center of bars
            vjust = 0.5 ,    # nudge above top of bar
            hjust = 0 ,
            angle = 0 , 
            fontface = "bold" ,
            size = 5) + 
  
  basic_size_plot(size_text = 20) + 
  theme(legend.position = "none"  ) + 
  geom_blank(data=dummy, aes(x = forcats::fct_rev(Short_name) , y = Energy )) + 
  labs(x = "NACE sections" ,  y = "Energy consumption (TWh)")


dev.off()

