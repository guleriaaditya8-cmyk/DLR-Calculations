###### INFORMATION ###### 
# File: Text.R
# Date: 2023-03-19
# Author: Kevin BELLINGUER
# Description: This script loads the user defined functions used to process text. 
#########################


fun_sparse_sentence <- function(str, n) {
  . <- strsplit(str, " +")[[1L]]
  paste0(., c(rep_len(c(rep(" ",n-1),"\n"), length(.)-1), ""), collapse = "")
}
