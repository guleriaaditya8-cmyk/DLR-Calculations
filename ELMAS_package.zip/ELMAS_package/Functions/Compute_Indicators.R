###### INFORMATION ###### 
# File: Compute_Indicators.R
# Date: 2023-03-19
# Author: Kevin BELLINGUER
# Description: This script loads the user defined functions used to analyse the data. 
#########################






Compute_TS_per_Class = function( db ){
  
  Temp_min = 16
  Month2keep = c(1,2,3,10,11,12)
  
  db_split = db %>% 
    
    dplyr::mutate( Day = as.Date(Time) , 
                   Month = lubridate::month(Time)) %>% 
    dplyr::filter( Month %in% Month2keep ) %>% 
    
    dplyr::group_by(Day , Class , Cluster , Power_level) %>% 
    dplyr::mutate(Temp_daily = mean(Temperature , na.rm = T) , 
                  Conso_daily = mean(Conso , na.rm = T)  ) %>% 
    dplyr::ungroup() %>% 
    
    dplyr::filter(Temp_daily <= Temp_min) %>% 
    dplyr::select( -Day) %>% 
    
    dplyr::group_split( Class, Power_level , Cluster ) 
  
  
  
  
  All_TS_indicator = foreach::foreach( index_split = 1 : length(db_split) ) %do% {
    
    Current_split = db_split[[index_split]] %>% 
      dplyr::select(-Time , -Conso , -Temperature) %>%
      unique()
    
  
    # Current_split %>%
    #   ggplot(data = . , aes(x = Temp_daily , y = Conso_daily )) +
    #   geom_point() +
    #   basic_size_plot(20)
    
    
    mod = lm(formula = "Conso_daily ~ Temp_daily" , data = Current_split )
    # mod = lm(formula = "Conso ~ Temperature" , data = Current_split )
    
    
    data.frame( "Cluster" = Current_split$Cluster %>% unique() , 
                "Class" = Current_split$Class %>% unique() , 
                "Power_level" = Current_split$Power_level %>% unique() , 
                "Alpha" = mod$coefficients[2] %>% unname() , 
                "Cor" = cor(x = Current_split$Conso_daily ,
                            y = Current_split$Temp_daily )^2)
  } %>% 
    dplyr::bind_rows()
  
  All_TS_indicator
}







Compute_diff_season = function( db ){
  
  start_winter = fasttime::fastPOSIXct("2018-12-21 00:00:00" , tz = "GMT")
  end_winter = fasttime::fastPOSIXct("2018-03-20 00:00:00" , tz = "GMT")
  
  start_ete = fasttime::fastPOSIXct("2018-06-21 00:00:00" , tz = "GMT")
  end_ete = fasttime::fastPOSIXct("2018-09-21 00:00:00" , tz = "GMT")
  
  db %>% 
    dplyr::mutate(Season = NA , 
                  Season = ifelse( Time <= end_winter | Time >= start_winter , "Winter" , Season ) , 
                  Season = ifelse(Time >= start_ete & Time <= end_ete , "Summer" , Season ) ) %>% 
    tidyr::drop_na(Season) %>% 
    
    dplyr::group_by( Class , Power_level , Cluster , Season) %>% 
    dplyr::summarise( Conso = mean(Conso , na.rm = T )) %>% 
    dplyr::ungroup() %>% 
    
    tidyr::pivot_wider(names_from = Season , values_from = Conso ) %>% 
    dplyr::mutate(Diff = Winter - Summer , 
                  Ratio = Winter / Summer )
  
}







Compute_diff_week_day_end = function(db){
  
  
  db %>% 
    dplyr::mutate( Day = lubridate::wday(Time , label = T , abbr = T ) , 
                   Day = as.character(Day) ,
                   Week_type = ifelse(Day %in% c( "sam\\." , "dim\\." ) , "Week_end" , "Working_day" ) ) %>% 
    
    dplyr::group_by(Class , Power_level , Cluster , Week_type ) %>% 
    dplyr::summarise(Conso = mean(Conso , na.rm = T )) %>% 
    dplyr::ungroup() %>% 
    
    tidyr::pivot_wider(names_from = Week_type , values_from = Conso ) %>% 
    dplyr::mutate(Diff = Working_day - Week_end , 
                  Ratio = Working_day / Week_end )
  
  
}







Compute_diff_hour = function( db ){
  
  db %>% 
    dplyr::mutate( Hour = lubridate::hour(Time ) , 
                   Day_type = ifelse(Hour %in% c( 0:7 , 19 : 23 ) , "Night" , "Day" ) ) %>% 
    
    dplyr::group_by(Class , Power_level , Cluster , Day_type ) %>% 
    dplyr::summarise(Conso = mean(Conso , na.rm = T )) %>% 
    dplyr::ungroup() %>% 
    
    tidyr::pivot_wider(names_from = Day_type , values_from = Conso ) %>% 
    dplyr::mutate(Diff = Day - Night , 
                  Ratio = Day / Night )
  
}