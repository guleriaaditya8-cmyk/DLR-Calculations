###### INFORMATION ###### 
# File: Plot_data.R
# Date: 2023-03-19
# Author: Kevin BELLINGUER
# Description: This script loads the user defined functions used to plot data. 
#########################



basic_size_plot = function(size_text){
  theme_bw() + 
    theme(plot.title = element_text(face = "bold" , 
                                    hjust = 0.5 , 
                                    size = size_text ) , 
          axis.text = element_text( size = size_text  - 4 ) , 
          axis.title = element_text( size = size_text ) , 
          strip.text.x = element_text( size = size_text ,
                                       face = "bold") ,
          strip.text.y = element_text( size = size_text ,
                                       face = "bold")
    )
}







Get_plot_Section_clusters = function( data4ploting ){
  
  library(tidytext)
  
  Angle = 0
  
  color_palette = data.frame( "Section" = c("A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T" ,"U") , 
                              "Assigned_color" = gg_color_hue(n = 21))
  
  manual_scale_colors <- setNames(color_palette$Assigned_color, color_palette$Section)
  
  Section_data = data4ploting %>%
    dplyr::select( Section , Cluster , Energy , Pct_Section , Conso_section, Section_fill , Pct_cluster , Short_name_section)  %>% 
    unique() %>% 
    dplyr::filter( Pct_Section  > 0.005 )
  
  
  dummy_section = Section_data %>% 
    
    dplyr::group_by(Cluster) %>% 
    dplyr::filter(Pct_Section == max(Pct_Section)) %>% 
    dplyr::ungroup() %>% 
    dplyr::rename( Values = Conso_section ) %>% 
    dplyr::mutate( Values = Values * 1.3 )
  
  
  
  plot_section = ggplot(data = Section_data ,
                        aes( y= reorder_within( x = Short_name_section , by = Pct_Section , within = Cluster) ,
                             x = Conso_section , 
                             fill = Section_fill  , 
                             label = scales::percent(Pct_Section , accuracy = 0.01) )  ) + 
    geom_segment(aes( yend = reorder_within( x = Short_name_section, by = Pct_Section , within = Cluster)  ,  
                      xend = 0 , 
                      color = Section_fill ) , linewidth = 6 #,colour="grey50"
    ) +
    
    labs( x = "Energy consumption (TWh)" , title = "NACE sections" , color = "Section") +
    
    scale_y_reordered() +
    scale_color_manual(values = manual_scale_colors) +
    
    basic_size_plot(size_text = 20)   + 
    facet_wrap( . ~ Cluster + Pct_cluster , nrow = 9 , scales = "free" , shrink = T , 
                strip.position= c("right","top")[1] , 
                labeller = label_bquote( atop( bold(.(as.character(Cluster)) ) ,italic(.( paste0("(" ,as.character(Pct_cluster),"%)" )  ))) ) ) +
    guides(color=guide_legend(nrow=1))  + 
    
    theme(legend.position = "bottom" , 
          axis.title.y = element_blank() ,
          legend.key.size = unit(1, 'cm') , 
          legend.title = element_text(size=22 , face = "bold") ,
          legend.text = element_text(size=18, face = "bold") ,
          # strip.text.y.right = element_text(angle = 0) , 
          axis.text.x = element_text(face = "bold") ,
          strip.text.y = element_blank() ) +
    
    geom_text(position = position_dodge(width = 0.9),    # move to center of bars
              vjust = 0.5 ,    # nudge above top of bar
              hjust = -0.1 ,
              angle = Angle , 
              fontface = "italic" ,
              size = 5) + 
    
    geom_blank( data = dummy_section , 
                aes(y = reorder_within( x = Short_name_section, by = Pct_Section , within = Cluster)  , 
                    x = Values ))
  
  plot_section
}










Get_plot_Classe_clusters = function( data4ploting ){
  
  library(tidytext)
  
  color_palette = data.frame( "Section" = c("A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T" ,"U") , 
                              "Assigned_color" = gg_color_hue(n = 21))
  
  manual_scale_colors <- setNames(color_palette$Assigned_color, color_palette$Section)
  
  Angle = 0
  
  
  Classe_data = data4ploting %>% 
    dplyr::select( Class , Cluster , Energy , Pct_Classe  , Conso_classe, Section_fill , Pct_cluster , Short_name_classe ) %>% 
    unique() %>% 
    dplyr::filter( Pct_Classe  > 0.025 )
  
  
  dummy_classe = Classe_data %>% 
    
    dplyr::group_by(Cluster) %>% 
    dplyr::filter(Pct_Classe == max(Pct_Classe)) %>% 
    dplyr::ungroup() %>% 
    dplyr::rename( Values = Conso_classe ) %>% 
    dplyr::mutate( Values = Values * 1.1 ) 
  
  
  
  
  
  plot_classe = ggplot(data = Classe_data ,
                       aes( y= reorder_within( x = Short_name_classe, by = Pct_Classe , within = Cluster) ,
                            x = Conso_classe , 
                            fill = Section_fill  , 
                            label = scales::percent(Pct_Classe , accuracy = 0.01) )  ) + 
    geom_segment(aes( yend = reorder_within( x = Short_name_classe, by = Pct_Classe , within = Cluster)  ,  
                      xend = 0 , 
                      color = Section_fill ) , linewidth = 6 #,colour="grey50"
    ) +
    
    labs( x = "Energy consumption (TWh)" , title = "NACE classes", color = "Section") +
    
    scale_y_reordered() +
    scale_color_manual(values = manual_scale_colors) +
    
    basic_size_plot(size_text = 20) + 
    facet_wrap( . ~ Cluster + Pct_cluster , nrow = 9 , scales = "free" , shrink = F , 
                strip.position= c("right","top")[1] , 
                labeller = label_bquote( atop( bold(.(as.character(Cluster)) ) ,italic(.( paste0("(" ,as.character(Pct_cluster),"%)" )  ))) ) ) +
    guides(color=guide_legend(nrow=1,byrow=TRUE)) +
    
    theme(legend.position = c("bottom","none")[1] , 
          legend.key.size = unit(1, 'cm') , 
          legend.title = element_text(size=22 , face = "bold") ,
          # axis.title.x = element_blank() ,
          axis.title.y = element_blank() ,
          strip.text.y.right = element_text(angle = 0) , 
          axis.text.x = element_text(face = "bold") ,
          strip.text.y = element_text( size = 18 ,
                                       face = "bold") ) +
    geom_text(position = position_dodge(width = 0.9),    # move to center of bars
              vjust = 0.5,    # nudge above top of bar
              hjust = -0.1 ,
              angle = Angle , 
              fontface = "italic" ,
              size = 5) + 
    
    geom_blank( data = dummy_classe , 
                aes(y = reorder_within( x = Short_name_classe, by = Pct_Classe , within = Cluster)  , 
                    x = Values )) 
  
  plot_classe
}





gg_color_hue = function(n) {
  hues = seq(15, 375, length = n + 1)
  hcl(h = hues, l = 65, c = 100)[1:n]
}





