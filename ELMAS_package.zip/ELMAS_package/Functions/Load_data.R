###### INFORMATION ###### 
# File: Load_data.R
# Date: 2023-03-19
# Author: Kevin BELLINGUER
# Description: This script loads the user defined functions used to load data. 
#########################


load_table_conv_Fr_An = function(){
  
  base_path = getwd()
  
  vroom::vroom( fs::path( base_path , "Inputs/Conversion_Fr_An.csv") , 
                col_types = vroom::cols() , 
                locale = vroom::locale(encoding = "CP1252"))
  
}






load_short_section_name = function(){
  
  library(h2o)
  
  temp = dplyr::bind_rows(    data.frame("Code.Section" = "0" , 
                                         "Section" = "Others" , 
                                         "Short_name" = "(0) Others") %>% dplyr::as_tibble() , 
                              Load_correspondance_table() %>% 
                                dplyr::select(Code.Section , Section) %>%
                                unique() %>% 
                                dplyr::mutate(New_name = tolower(Section) , 
                                              New_name = stringr::str_to_sentence( New_name ) , 
                                              Word_name = stringr::word(New_name , 1)) %>% 
                                
                                dplyr::mutate( Word_name = ifelse(Word_name =="Water" , "Water supply" , Word_name) , 
                                               Word_name = ifelse(Word_name =="Real" , "Real estate" , Word_name) ,
                                               Word_name = ifelse(Word_name =="Public" , "Public admin..." , Word_name) ,
                                               Word_name = ifelse(Word_name =="Human" , "Human health" , Word_name) , 
                                               Word_name = ifelse(Word_name =="Other" , "Other service" , Word_name) , 
                                               Word_name = ifelse(Code.Section =="T" , "Activities of house..." , Word_name ) , 
                                               Word_name = ifelse(Code.Section =="U" , "Activities of extra..." , Word_name ) ) %>% 
                                
                                dplyr::mutate( N_char_raw = nchar(New_name) , 
                                               N_char_new = nchar(Word_name) ) %>% 
                                dplyr::mutate( N_char_new = ifelse(Code.Section %in% c("O" , "T" , "U") , N_char_raw , N_char_new )  ) %>% 
                                dplyr::mutate( Word_name = ifelse( N_char_raw > N_char_new , paste0(Word_name, " ..." ) , Word_name ) , 
                                               Word_name = paste0( "(" , Code.Section , ") " , Word_name )) %>% 
                                dplyr::select(Code.Section , Section, Word_name) %>% 
                                dplyr::rename(Short_name = Word_name)  ) 
  
  temp %>%   
    dplyr::mutate( Short_name = factor(x = Short_name , levels = temp$Short_name)) %>% 
    dplyr::mutate(Order_section = as.numeric(Short_name) )
  
}










Load_correspondance_table = function(){

  Correspondance_table = fs::path("Inputs/RAMON.csv") %>% 
    vroom::vroom(file = . , delim = ";" , 
                 col_types = vroom::cols() ) %>% 
    dplyr::select(Code , Description ) %>% 
    dplyr::mutate( NAF = Code , 
                   Code = stringr::str_replace(string = Code , pattern = "\\." , replacement = "") 
                   # Code = ifelse(Code %in% Alphabet_string, NA , Code ) , 
                   # Code = as.numeric(Code)
    )
  
  
  temp_list = Correspondance_table %>% 
    dplyr::mutate(Count = ifelse(Code %in% Alphabet_string, 1 , 0 ) , 
                  Count = cumsum(Count)) %>%
    dplyr::group_split(Count)
  
  
  
  
  Correspondance_table = foreach::foreach(index_split = 1 : length(temp_list) ) %do% {
    
    Ghost = temp_list[[index_split]]
    Section_name = Ghost$Description[1]
    Ghost %>% dplyr::mutate(Section = Section_name)
  } %>% 
    dplyr::bind_rows() %>% 
    dplyr::filter(! Code %in% Alphabet_string) %>% 
    dplyr::mutate(Code = ifelse(Code %in% Alphabet_string, NA , Code ) ,
                  Code = as.numeric(Code)
    ) %>% 
    dplyr::select(-Count)
  
  
  
  
  # Pb: 32.2 et 3.22 -> 322... 
  # We remove instance that appear twice
  
  Code2remove = c("Manufacture of musical instruments" ,
                  "Manufacture of articles of fur" , 
                  "Manufacture of knitted and crocheted apparel" , 
                  "Sawmilling and planing of wood" ,
                  "Manufacture of jewellery, bijouterie and related articles" , 
                  "Aquaculture" )
  
  Outputs = Correspondance_table %>% 
    dplyr::as_tibble() %>% 
    dplyr::filter(! Description %in% Code2remove ) %>% 
    dplyr::filter(! (Description == "Mixed farming" & Code == 150) ) %>% 
    unique() 
  
  dplyr::left_join( x = Outputs , 
                    y = fs::path( "Inputs/RAMON.csv") %>% 
                      vroom::vroom(file = . , delim = ";" , col_types = vroom::cols() ) %>% 
                      dplyr::filter(Code %in% Alphabet_string) %>% 
                      dplyr::select(Code , Description  ) %>% 
                      dplyr::rename(Code.Section = Code , 
                                    Section = Description  ) , 
                    by = "Section") %>% 
    dplyr::relocate(Code.Section , Section , Description , Code , NAF ) %>% 
    dplyr::mutate( Code.Section = ifelse( is.na(Code.Section) , "0" , Code.Section ) , 
                   Section = ifelse( is.na(Section) , "Other" , Section ) ,
                   Description = ifelse( is.na(Description) , "Other" , Description ) ,
                   NAF = ifelse( is.na(NAF) , "0" , NAF ) )
  
}










load_short_classe_name = function( Max_char ){
  
  library(h2o)
  
  temp = dplyr::bind_rows( data.frame("Classe" = c("0" , "5/6/7/8" , "23.4/23.3" , "33.17/33.16/33.15" , "13.2/13.3" , "30.2/30.1") ,
                                      "Short_name" = c("(0) Others" ,
                                                       "(5/6/7/8) Extraction and mining ..." ,
                                                       "(23.3/23.4) Manufacture of clay/ceramic ..." , 
                                                       "(33.15/33.16/33.17) Repair and maintenance ..." , 
                                                       "(13.2/13.3) Textile-related activities ..." , 
                                                       "(30.1/30.2) Manufacture of transportation ...") ) %>% 
                             dplyr::as_tibble() , 
                           
                           Load_correspondance_table() %>% 
                             dplyr::select(NAF , Description) %>%
                             unique() %>% 
                             dplyr::rename(Classe = NAF ) %>% 
                             dplyr::mutate(  Short_name = Split_character_whole_word( sentence = Description, 
                                                                                      Max_char = Max_char ) ) %>% 
                             dplyr::mutate( Nchar_old = nchar(Description) , 
                                            Nchar_new = nchar(Short_name) , 
                                            Short_name = paste0( "(" , Classe , ") "  , Short_name ) , 
                                            Short_name = ifelse(Nchar_new < Nchar_old , paste0( Short_name , " ...") , Short_name )) %>% 
                             dplyr::select(-Description , -Nchar_new, -Nchar_old) ) 
  
  # temp %>% dplyr::filter( Classe == "18.1")
  
  temp %>%
    dplyr::mutate( Short_name = factor(x = Short_name , levels = temp$Short_name)) %>%
    dplyr::mutate(Order_classe = as.numeric(Short_name) )
  
}







load_normalise_times_series_conso = function(path2load , Power_level_name){
  
  loaded_data = vroom::vroom(file = path2load  , 
                             show_col_types = FALSE  , 
                             locale = vroom::locale(decimal_mark = ",") ) %>% 
    tidyfast::dt_pivot_longer(cols = -Time , names_to = "Class", values_to = "Conso") %>% 
    dplyr::filter(Class != "0") %>% 
    dplyr::as_tibble() %>% 
    dplyr::mutate(Conso = as.numeric(Conso)) %>% 
    dplyr::group_by(Class) %>% 
    dplyr::mutate( Energy = sum(Conso , na.rm = T) ) %>% 
    dplyr::ungroup() 
  
  loaded_data %>% 
    dplyr::group_by(Class) %>% 
    dplyr::mutate(Mean = mean(Conso , na.rm = T) ,
                  Sd = sd(Conso , na.rm = T) ) %>% 
    dplyr::ungroup() %>% 
    dplyr::mutate( Conso = (Conso - Mean) / Sd ) %>% 
    dplyr::select(-Mean , -Sd) %>% 
    dplyr::mutate(Power_level = Power_level_name )
  
}





Load_correspondance_lcuster_ID_name = function(){
  
  data.frame( "ID" = 1:18 , 
              "Name" = c("Manufacturing process" , "Trades (non food)" , "Trades (food)" , "Education" , "Office" , "Crop farming and transportation" , 
                         "Livestock farming" , "Water supply and telecommunications" , "Restaurants" , "Food industry" , "Wine industry" , "Energy supply and rental activities" , 
                         "Hotels" , "Bakery" , "Property management companies" , "Hospital activities" , "Recreational and social activities" , "Construction") ) %>% 
    dplyr::mutate( Name_id = paste0("(" , ID, ") " , Name) )
}





load_times_series_conso = function(path2load ){
  
  vroom::vroom(file = path2load  , show_col_types = FALSE  , locale = vroom::locale(decimal_mark = ",") ) %>% 
    tidyfast::dt_pivot_longer(cols = -Time , names_to = "Class", values_to = "Conso") %>% 
    dplyr::filter(Class != "0") %>% 
    dplyr::as_tibble() %>% 
    dplyr::mutate(Conso = as.numeric(Conso)) 
  
  
}






load_raw_times_series_conso = function(path2load , Power_level_name){
  
  vroom::vroom(file = path2load  , show_col_types = FALSE  , locale = vroom::locale(decimal_mark = ",") ) %>% 
    tidyfast::dt_pivot_longer(cols = -Time , names_to = "Class", values_to = "Conso") %>% 
    dplyr::as_tibble() %>% 
    dplyr::filter(Class != "0") %>% 
    dplyr::mutate(Conso = as.numeric(Conso)) %>% 
    dplyr::mutate(Power_level = Power_level_name )
  
}
