###### INFORMATION ###### 
# File: Generate_Time_series_averaged_Cluster.R
# Date: 2023-03-19
# Author: Kevin BELLINGUER
# Description: This script is used to generate the averaged time series for each cluster.

# WARNING: the script is provided but not the confidential data used to generate the data (as a result, it is not possible to generate the data).

#########################

source(fs::path("0_load_packages_functions.R") )




Day_correspondance = data.frame(Dow = 1:7 , 
                                Dow_name = c("Mon." , "Tues." , "Wed." , "Thurs." , "Fri." , "Sat." , "Sun.")) %>% 
  dplyr::mutate(Dow_name = factor(x = Dow_name , 
                                  levels = c("Mon." , "Tues." , "Wed." , "Thurs." , "Fri." , "Sat." , "Sun.") ) )





# DATA LOADING ------------------------------------------------------------

Clustered_data = 
  vroom::vroom( file = fs::path("Inputs/Clusters_after_manual_reclassification.csv") , 
                col_types = vroom::cols() ) %>%
  dplyr::filter(Class != "0") 



PRO_db = load_normalise_times_series_conso( path2load = fs::path("C:/Users/kevin.bellinguer/Documents/MOSAIC/Publication/Data/Confidential/" , 
                                                                 "PRO_Averaged_NACE_Time_series_2018.csv")  , 
                                            Power_level_name = "LV-a" )

MV_db = load_normalise_times_series_conso( path2load = fs::path("C:/Users/kevin.bellinguer/Documents/MOSAIC/Publication/Data/Confidential/" , 
                                                                "MV_Averaged_NACE_Time_series_2018.csv")  , 
                                           Power_level_name = "MV" )

LV_db = load_normalise_times_series_conso( path2load = fs::path("C:/Users/kevin.bellinguer/Documents/MOSAIC/Publication/Data/Confidential/" , 
                                                                "LV_Averaged_NACE_Time_series_2018.csv")  , 
                                           Power_level_name = "LV-b" )


All_data = dplyr::bind_rows( PRO_db , LV_db , MV_db)


Data2gather = dplyr::left_join( y = Clustered_data , 
                                x = All_data , 
                                by = c("Class" , "Power_level") ) %>% 
  dplyr::mutate(Day = as.Date(Time) , 
                Week = lubridate::week(Time) ,
                Dow = lubridate::wday(Time , week_start = 1) , 
                Hod = lubridate::hour(Time)) %>% 
  dplyr::left_join(x = . , 
                   y = Day_correspondance , 
                   by = "Dow") %>% 
  dplyr::select(-Dow) 




Data2save = Data2gather %>% 
  dplyr::group_by(Cluster, Time) %>% 
  dplyr::summarise( Conso = sum( Conso * Energy , na.rm = T )/sum( Energy , na.rm = T ) ) %>%
  dplyr::ungroup() %>% 
  tidyr::pivot_wider( data = . , names_from = Cluster , values_from = Conso)


Data2save %>% write.csv2(x = . , 
                         file = fs::path("Outputs" , "Time_series_averaged_18_clusters.csv") , 
                         row.names = F )


