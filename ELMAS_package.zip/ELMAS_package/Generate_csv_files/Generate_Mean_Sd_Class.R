###### INFORMATION ###### 
# File: Generate_Mean_Sd_Class.R
# Date: 2023-03-19
# Author: Kevin BELLINGUER
# Description: This script is used to generate the mean and the standard deviation of the input time series.

# WARNING: the script is provided but not the confidential data used to generate the plot (as a result, it is not possible to generate the graph)


#########################

source(fs::path("0_load_packages_functions.R") )






# DATA LOADING ------------------------------------------------------------


Table_section_class = Load_correspondance_table()


PRO_ts = load_raw_times_series_conso( path2load = fs::path("C:/Users/kevin.bellinguer/Documents/MOSAIC/Publication/Data/Confidential/" , 
                                                           "PRO_Averaged_NACE_Time_series_2018.csv")  , 
                                      Power_level_name = "LV-a" ) 

MV_ts = load_raw_times_series_conso( path2load = fs::path("C:/Users/kevin.bellinguer/Documents/MOSAIC/Publication/Data/Confidential/" , 
                                                          "MV_Averaged_NACE_Time_series_2018.csv")  , 
                                     Power_level_name = "MV" ) 


LV_ts = load_raw_times_series_conso( path2load = fs::path("C:/Users/kevin.bellinguer/Documents/MOSAIC/Publication/Data/Confidential/" , 
                                                          "LV_Averaged_NACE_Time_series_2018.csv")  , 
                                     Power_level_name = "LV-b" ) 

All_data = dplyr::bind_rows( PRO_ts , LV_ts , MV_ts ) 








# DATA PROCESSING ------------------------------------------------------------



All_data %>% 
  dplyr::group_by( Class , Power_level ) %>% 
  dplyr::summarise(Mean = mean(Conso , na.rm = T) , 
                   Sd = sd( Conso , na.rm = T) ) %>% 
  dplyr::ungroup() %>% 
  
  dplyr::left_join( x = . , 
                    y = Table_section_class %>% 
                      dplyr::select(NAF , Code.Section ) %>%  
                      dplyr::rename(Class = NAF ,
                                    Section = Code.Section) , 
                    by = "Class") %>% 

  dplyr::relocate(Power_level , Section , Class , Mean , Sd) %>% 

  write.csv2( x = . ,
              file = fs::path("Outputs" , "Mean_Sd_Nace_classes_time_series.csv") , 
              row.names = F )
