###### INFORMATION ###### 
# File: Generate_Energy_per_surface.R
# Date: 2023-03-19
# Author: Kevin BELLINGUER
# Description: This script is used to generate the annyal energy consumption and the surface of NACE classes.

# WARNING: the script is provided but not the confidential data used to generate the plot (as a result, it is not possible to generate the graph)


#########################

source(fs::path("0_load_packages_functions.R") )






# DATA LOADING ------------------------------------------------------------


Raw_data = vroom::vroom(file = fs::path("C:/Users/kevin.bellinguer/Documents/MOSAIC/Publication/Data/Confidential/" , "Data_consoM2.csv") , 
                        col_types = vroom::cols() )



Correspondance_table = fs::path("Inputs" , "RAMON.csv") %>% 
  vroom::vroom(file = . , delim = ";" , 
               col_types = vroom::cols() ) %>% 
  dplyr::select(Code , Description ) %>% 
  dplyr::mutate( NAF = Code , 
                 Code = stringr::str_replace(string = Code , pattern = "\\." , replacement = "") 
  ) %>% 
  dplyr::select(-Code)


Table_Fr_An = load_table_conv_Fr_An() %>% tidytable::select.(-NAF) 

Conso_raw_data = Raw_data %>% 
  tidytable::as_tidytable() %>% 
  tidytable::mutate.( Type = c("Conso" , "Surface" , "Conso_m2" ) ) %>% 
  # tidytable::slice.(1) %>% 
  tidytable::pivot_longer.(cols = -Type ,  names_to = "NAF" , values_to = "Conso") %>% 
  tidytable::filter.(Conso != 0)





# DATA PROCESSING ------------------------------------------------------------

Temp = Raw_data %>% 
  tidytable::as_tidytable() %>% 
  tidytable::mutate.( Type = c("Conso" , "Surface" , "Conso_m2" ) ) %>% 
  tidytable::pivot_longer.( cols = -Type ,  names_to = "NAF" , values_to = "Value") %>% 
  tidytable::filter.(Value != 0) %>% 
  
  tidytable::filter.( NAF != "0_Autres") %>% 
  
  tidytable::rename.( French_descript = NAF ) 
# tidytable::left_join.( x = . , 
#                        y = Table_Fr_An , 
#                        by = c("French_descript") )




Missing_NAF = c("01.26" , "03.11" , "03.12" , "43.13" , "46.64" , "62.01" , "62.02" , "62.03" , "62.09" , "66.21" , 
                "75.00" , "77.21" , "77.34" , "77.35" , "80.30" , "90.01" , "90.02" , "90.03" , "90.04" , "91.01" , 
                "91.02" , "91.03" , "91.04" , "92.00" , "95.25" , "96.01" , "96.02" , "96.03" , "96.04" , "96.09" , "98.10" , "99.00") 
Missing_descript = c("01.26_Culture de fruits oléagineux" ,
                     "03.11_Pêche en mer" , 
                     "03.12_Pêche en eau douce" ,
                     "43.13_Forages et sondages" ,
                     "46.64_Commerce de gros (commerce interentreprises) de machines pour l'industrie textile et l'habillement" , 
                     "62.01_Programmation informatique" ,
                     "62.02_Conseil en systèmes et logiciels informatiques" , 
                     "62.03_Gestion d'installations informatiques" , 
                     "62.09_Autres activités informatiques" , 
                     "66.21_Évaluation des risques et dommages" , 
                     "75.00_Activités vétérinaires" , 
                     "77.21_Location et location-bail d'articles de loisirs et de sport" , 
                     "77.34_Location et location-bail de matériels de transport par eau" , 
                     "77.35_Location et location-bail de matériels de transport aérien" , 
                     "80.30_Activités d'enquête" , 
                     "90.01_Arts du spectacle vivant" , 
                     "90.02_Activités de soutien au spectacle vivant" , 
                     "90.03_Création artistique relevant des arts plastiques" , 
                     "90.04_Gestion de salles de spectacles" , 
                     "91.01_Gestion des bibliothèques et des archives" , 
                     "91.02_Gestion des musées" , 
                     "91.03_Gestion des sites et monuments historiques et des attractions touristiques similaires" , 
                     "91.04_Gestion des jardins botaniques et zoologiques et des réserves naturelles" , 
                     "92.00_Organisation de jeux de hasard et d'argent" , 
                     "95.25_Réparation d'articles d'horlogerie et de bijouterie" , 
                     "96.01_Blanchisserie-teinturerie de gros" , 
                     "96.02_Coiffure" , 
                     "96.03_Services funéraires" , 
                     "96.04_Entretien corporel" ,
                     "96.09_Autres services personnels n.c.a." , 
                     "98.10_Activités indifférenciées des ménages en tant que producteurs de biens pour usage propre" , 
                     "99.00_Activités des organisations et organismes extraterritoriaux" )


Conso_per_surface = tidytable::bind_rows.( Correspondance_table %>% 
                                             dplyr::filter(NAF %in% Missing_NAF ) %>% 
                                             dplyr::rename( English_descript = Description , 
                                                            NACE = NAF ) %>% 
                                             dplyr::mutate( French_descript = Missing_descript ) , 
                                           Table_Fr_An ) %>% 
  
  tidytable::left_join.( x = Temp , 
                         y = . , 
                         by = c("French_descript") )  %>% 
  tidytable::select.( -French_descript ) %>% 
  tidytable::rename.( Class = NACE , 
                      Description = English_descript ) %>% 
  tidytable::pivot_wider.(names_from = Type , values_from = Value) %>% 
  tidytable::relocate.(  Class , Description  ) %>% 
  tidytable::rename.( Energy = Conso ,
                      Energy_m2 = Conso_m2  )




Conso_per_surface %>% 
  write.csv2( file = fs::path("Outputs" , "Energy_consumption_per_unit_Surface_area.csv") , 
              row.names = F)






## MOYENNE ARITHMETIQUE

Clustered_data_after =   vroom::vroom( file = fs::path("Inputs/Clusters_after_manual_reclassification.csv") , 
                                       col_types = vroom::cols() ) %>%
  dplyr::filter(Class != "0") 



Clustered_data_after %>% 
  tidytable::left_join.( x = . , 
                         y = Conso_per_surface %>% tidytable::select.(-Description) , 
                         by = c("Class")) %>% 
  tidytable::summarise.( Conso = sum(Energy , na.rm = T) ,
                         Surface = sum(Surface , na.rm = T) ,
                         .by = "Cluster" ) %>% 
  tidytable::mutate.( Conso_m2 = Conso / Surface )


Clustered_data_after %>% 
  tidytable::left_join.( x = . , 
                         y = Conso_per_surface , 
                         by = c("Class")) %>% 
  tidytable::filter.( is.na(Energy) ) %>% 
  tidytable::pull.(Class) %>% unique()

## MISSSING CLASSES : "01.29" "84.22" "84.24" "97.00" "01.12" "01.15" "02.30" "17.11" "84.21" "98.20"









