###### INFORMATION ###### 
# File: Generate_Time_series_Cluster.R
# Date: 2023-03-19
# Author: Kevin BELLINGUER
# Description: This script is used to generate the load profiles of the 18 clusters.
#########################

source(fs::path("0_load_packages_functions.R") )








# DATA LOADING ------------------------------------------------------------

Clustered_data = 
  vroom::vroom( file = fs::path("Inputs/Clusters_after_manual_reclassification.csv") , 
                col_types = vroom::cols() ) %>%
  dplyr::filter(Class != "0") 




PRO_db = load_times_series_conso( path2load = fs::path("C:/Users/kevin.bellinguer/Documents/MOSAIC/Publication/Data/2upload4Article/" , 
                                                       "PRO_Averaged_NACE_Time_series_2018.csv") ) %>% 
  dplyr::mutate(Power_level = "LV-a")

MV_db = load_times_series_conso( path2load = fs::path("C:/Users/kevin.bellinguer/Documents/MOSAIC/Publication/Data/2upload4Article/" , 
                                                      "MV_Averaged_NACE_Time_series_2018.csv")  ) %>% 
  dplyr::mutate(Power_level = "MV")


LV_db = load_times_series_conso( path2load = fs::path("C:/Users/kevin.bellinguer/Documents/MOSAIC/Publication/Data/2upload4Article/" , 
                                                      "LV_Averaged_NACE_Time_series_2018.csv")   ) %>% 
  dplyr::mutate(Power_level = "LV-b")


All_data = dplyr::bind_rows( PRO_db , LV_db , MV_db)




All_weights = vroom::vroom( file = fs::path( "Inputs/Annual_energy_weights.csv" ) ,
                            col_types = vroom::cols() , 
                            locale = vroom::locale(decimal_mark = ","))



All_data = All_data %>%
  
  dplyr::left_join( x = . , 
                    y = All_weights , 
                    by = c("Class" , "Power_level")) 







# DATA PROCESSING ------------------------------------------------------------

Data2gather = dplyr::left_join( y = Clustered_data , 
                                x = All_data , 
                                by = c("Class" , "Power_level") )



Output = Data2gather %>% 
  dplyr::group_by(Cluster , Time) %>% 
  dplyr::summarise( Mean = sum( Conso * Energy , na.rm = T ) / sum( Energy , na.rm = T ) ) %>%
  dplyr::ungroup() %>% 
  tidyr::pivot_wider(id_cols = Time , names_from = Cluster , values_from = Mean) 


# Output %>%
#   dplyr::filter(is.na("18"))


Output %>% 
  ggplot( data = . , mapping = aes(x = Time , y = `18` ))+
  geom_line()+ 
  basic_size_plot(size_text = 22)


Output %>% 
  write.csv2(file = fs::path("Outputs" , 
                             "Time_series_18_clusters.csv") , 
             row.names = F)


