###### INFORMATION ###### 
# File: 0_load_packages_functions.R
# Date: 2023-03-19
# Author: Kevin BELLINGUER
# Description: This script is load the relevant packages and functions used to analyse the ELMAS dataset.
#########################

cat("\014")
rm(list = ls())
gc()



# LOAD FUNCTIONS ----------------------------------------------------------

## Install missing packages
list.of.packages <- c("ggplot2", "tidyverse" , "magrittr" , "foreach" , "ggrepel" , "vroom" , "fs" , "tidyr" , 
                      "h2o" , "tidytext" , "stringr" , "ggpubr")
new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
if(length(new.packages) > 0) install.packages(new.packages)


## Load functions
library(tidyverse)
library(magrittr)
library(ggplot2)
library(foreach)
library(ggrepel)
library(pals)
library(vroom)
library(fs)
library(tidyr)
library(tidytext)
library(ggpubr)



# LOAD USER DEFINED FUNCTIONS ---------------------------------------------

source(fs::path("Functions/Load_data.R"))
source(fs::path("Functions/Plot_data.R"))
source(fs::path("Functions/Text.R"))
source(fs::path("Functions/Compute_Indicators.R"))


## MAIN PATHS

Main_path = getwd()


## MISCELLANOUS INFORMATION

Alphabet_string = c("A" , "B" ,  "C" , "D",  "E" , "F" , "G" , "H" , 
                    "I", "J" , "K" , "L" , "M" , "N" , "O" , "P" , 
                    "Q" , "R" , "S" , "T" , "U" , "V" , "W")


Table_Fr_An = load_table_conv_Fr_An()
Section_name = load_short_section_name()


